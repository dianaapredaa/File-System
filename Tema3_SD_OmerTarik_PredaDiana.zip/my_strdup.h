// Copyright 2021 - 2022 Omer Tarik Ilhan & Preda Diana 314CA
#ifndef MY_STRDUP_H
#define MY_STRDUP_H

char* strdup(char* string);

#endif  // MY_STRDUP_H
